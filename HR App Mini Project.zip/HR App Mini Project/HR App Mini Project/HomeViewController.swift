//
//  ViewController.swift
//  HR App Mini Project
//
//  Created by Razan alshatti on 29/02/2024.
//

import UIKit
import SnapKit

class HomeViewController: UIViewController, UITextFieldDelegate {
    let MyTextField = UITextField()
    let myButton = UIButton(type: .system)
    let nameTextField = UITextField()
    let salaryTextField = UITextField()
    let emailTextField = UITextField()
    let phoneTextField = UITextField()
    let ibanTextField = UITextField()
    


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        title = NSLocalizedString("navigation_title_employee_info", comment: "")


        subview()
        setupUI()
        AutoLayout()
        setupNavigationBar()
        phoneTextField.delegate = self
        
        myButton.addTarget(self, action: #selector(saveButton), for: .touchUpInside)


    }
    
    func subview(){
        view.addSubview(MyTextField)
        view.addSubview(myButton)
        view.addSubview(nameTextField)
        view.addSubview(salaryTextField)
        view.addSubview(emailTextField)
        view.addSubview(phoneTextField)
        view.addSubview(ibanTextField)
    }
    
    
    func setupUI(){

        MyTextField.placeholder = NSLocalizedString("placeholder_image", comment: "")
        nameTextField.placeholder = NSLocalizedString("placeholder_name", comment: "")
        emailTextField.placeholder = NSLocalizedString("placeholder_email", comment: "")
        phoneTextField.placeholder = NSLocalizedString("placeholder_phone", comment: "")
        salaryTextField.placeholder = NSLocalizedString("placeholder_salary", comment: "")
        ibanTextField.placeholder = NSLocalizedString("placeholder_iban", comment: "")

        myButton.setTitle(NSLocalizedString("button_submit", comment: ""), for: .normal)

        
    }
    
    func AutoLayout(){
        
        myButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-20)
            make.width.equalTo(300)
            make.height.equalTo(50)
            myButton.backgroundColor = .systemGray
            myButton.setTitleColor(.white, for: .normal)
            myButton.titleLabel?.font = UIFont.systemFont(ofSize: 16)
            myButton.layer.cornerRadius = 10
            myButton.layer.borderWidth = 1
            myButton.layer.borderColor = UIColor.black.cgColor
        }

        
        MyTextField.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(40)
            MyTextField.font = UIFont.systemFont(ofSize: 14)
            MyTextField.textColor = .darkGray
            MyTextField.textAlignment = .center
        
        }
        
        nameTextField.snp.makeConstraints { make in
            make.bottom.equalTo(MyTextField.snp.bottom).offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(40)
            nameTextField.font = UIFont.systemFont(ofSize: 14)
            nameTextField.textColor = .darkGray
            nameTextField.textAlignment = .center
        }
        salaryTextField.snp.makeConstraints { make in
            make.bottom.equalTo(nameTextField.snp.bottom).offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(40)
            salaryTextField.font = UIFont.systemFont(ofSize: 14)
          salaryTextField.textColor = .darkGray
          salaryTextField.textAlignment = .center
        }
        emailTextField.snp.makeConstraints { make in
            make.bottom.equalTo(salaryTextField.snp.bottom).offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(40)
            emailTextField.font = UIFont.systemFont(ofSize: 14)
         emailTextField.textColor = .darkGray
         emailTextField.textAlignment = .center
        }
        phoneTextField.snp.makeConstraints { make in
            make.bottom.equalTo(emailTextField.snp.bottom).offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(40)
            phoneTextField.font = UIFont.systemFont(ofSize: 14)
         phoneTextField.textColor = .darkGray
         phoneTextField.textAlignment = .center
        }
        ibanTextField.snp.makeConstraints { make in
            make.bottom.equalTo(phoneTextField.snp.bottom).offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(40)
            ibanTextField.font = UIFont.systemFont(ofSize: 14)
        ibanTextField.textColor = .darkGray
        ibanTextField.textAlignment = .center
        }
        
        

        
    }
    
    @objc func saveButton(){
        //1- connection with 2nd VC
        let employeeVC = EmployeeViewController()
        //2- make sure the 2nd vc has var to hold the data [2vd]
        //3- transfer the data
        employeeVC.RecievedImagename = MyTextField.text
        employeeVC.Recievedname = nameTextField.text
        employeeVC.Recievedsalary = salaryTextField.text
        employeeVC.Recievedemail = emailTextField.text
        employeeVC.Recievedphone = phoneTextField.text
        employeeVC.Recievediban = ibanTextField.text

        //4- Go to the next page
        self.navigationController?.pushViewController(employeeVC, animated: true)
    }
    
    func setupNavigationBar(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithDefaultBackground()
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "info.circle"),
            style: .plain,
            target: self,
            action: #selector(signupTapped)
            )
        navigationItem.leftBarButtonItem?.tintColor = UIColor.red

    }
    @objc func signupTapped() {
        let instructionVC = InstructionsViewController()
        instructionVC.modalPresentationStyle = .popover
        self.present(instructionVC, animated: true)
        
    }
   
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == phoneTextField {
            let currentText = textField.text ?? ""
            guard let stringRange = Range(range, in: currentText) else { return false }
            let newText = currentText.replacingCharacters(in: stringRange, with: string)
            
            if newText.count > 8 {
                // Shake the screen
                let animation = CABasicAnimation(keyPath: "position")
                animation.duration = 0.05
                animation.repeatCount = 5
                animation.autoreverses = true
                animation.fromValue = NSValue(cgPoint: CGPoint(x: textField.center.x - 10, y: textField.center.y))
                animation.toValue = NSValue(cgPoint: CGPoint(x: textField.center.x + 10, y: textField.center.y))
                textField.layer.add(animation, forKey: "position")
                
                // Localized error message
                let errorMessage = NSLocalizedString("error_phone_exceed_limit", comment: "")
                let alert = UIAlertController(title: NSLocalizedString("error_title", comment: ""), message: errorMessage, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("ok_button", comment: ""), style: .default, handler: nil))
                present(alert, animated: true, completion: nil)
                
                return false
            }
        }
        return true
    }
}

