//
//  InstructionsViewController.swift
//  HR App Mini Project
//
//  Created by Razan alshatti on 29/02/2024.
//

import UIKit

class InstructionsViewController: UIViewController {
    let hrLabel = UILabel()
    let infoLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = NSLocalizedString("navigation_title_instructions", comment: "")

        // Do any additional setup after loading the view.
        subview()
        setupUI()
        AutoLayout()
    }
    
    func subview(){
        view.addSubview(hrLabel)
        view.addSubview(infoLabel)
    }
    func setupUI(){
        hrLabel.text = NSLocalizedString("label_hr_instructions", comment: "")
        hrLabel.textColor = .black
        hrLabel.font = UIFont.boldSystemFont(ofSize: 20.0)
        
        infoLabel.text = " Company Policy📕\n\n"
        infoLabel.textColor = .black
        infoLabel.text = NSLocalizedString("label_info_text", comment: "")

        infoLabel.font = UIFont.systemFont(ofSize: 18.0)
        infoLabel.numberOfLines = 30
        

    }
    
    func AutoLayout(){
        hrLabel.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            make.centerX.equalToSuperview()
        }
        infoLabel.snp.makeConstraints { make in
            make.bottom.equalTo(hrLabel.snp.bottom).offset(250)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)

        }
    }


}
