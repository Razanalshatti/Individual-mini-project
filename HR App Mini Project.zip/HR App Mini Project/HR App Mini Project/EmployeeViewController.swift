//
//  EmployeeViewController.swift
//  HR App Mini Project
//
//  Created by Razan alshatti on 29/02/2024.
//

import UIKit

class EmployeeViewController: UIViewController ,UITextFieldDelegate{
    
    //2- make surethe 2nd vc has var to hold the data [2vd]
    var RecievedImagename: String?
    var Recievedname: String?
    var Recievedsalary: String?
    var Recievedemail: String?
    var Recievedphone: String?
    var Recievediban: String?
    var profileImageView = UIImageView()
    
    let Homepage = HomeViewController()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = NSLocalizedString("navigation_title_employee_info", comment: "")

        //5- Display details
        profileImageView.image = UIImage(named: RecievedImagename ?? "")
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.clipsToBounds = true
        profileImageView.layer.cornerRadius = 10
        Homepage.nameTextField.text = (Recievedname ?? "")
        Homepage.salaryTextField.text = (Recievedsalary ?? "")
        Homepage.emailTextField.text = (Recievedemail ?? "")
        Homepage.phoneTextField.text = (Recievedphone ?? "")
        Homepage.ibanTextField.text = (Recievediban ?? "")


        // Do any additional setup after loading the view.
        
        subview()
        AutoLayout()
        createView()
    }
    
    let myView = UIView()
    
    func createView(){
        myView.frame = CGRect(x: 50, y: 150, width: 300, height: 600)
        myView.backgroundColor = .gray
        myView.layer.cornerRadius = 25
        myView.layer.borderWidth = 2
        
        self.view.addSubview(myView)
    }
    func subview(){
        myView.addSubview(profileImageView)
        myView.addSubview(Homepage.nameTextField)
        myView.addSubview(Homepage.salaryTextField)
        myView.addSubview(Homepage.emailTextField)
        myView.addSubview(Homepage.phoneTextField)
        myView.addSubview(Homepage.ibanTextField)


    }
    func AutoLayout(){
        profileImageView.snp.makeConstraints { make in
            make.top.equalTo(myView.snp.top).offset(20) // Use myView's top anchor
            make.centerX.equalToSuperview()
            make.width.height.equalTo(250)
        }
        Homepage.nameTextField.snp.makeConstraints { make in
            make.bottom.equalTo(profileImageView.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            Homepage.nameTextField.font = UIFont.systemFont(ofSize: 14)
            Homepage.nameTextField.textColor = .darkGray
            Homepage.nameTextField.textAlignment = .center
        }

        Homepage.emailTextField.snp.makeConstraints { make in
            make.bottom.equalTo(Homepage.nameTextField.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            Homepage.emailTextField.font = UIFont.systemFont(ofSize: 14)
            Homepage.emailTextField.textColor = .darkGray
            Homepage.emailTextField.textAlignment = .center
        }
        Homepage.phoneTextField.snp.makeConstraints { make in
            make.bottom.equalTo(Homepage.emailTextField.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            Homepage.phoneTextField.font = UIFont.systemFont(ofSize: 14)
            Homepage.phoneTextField.textColor = .darkGray
            Homepage.phoneTextField.textAlignment = .center
        }
        Homepage.salaryTextField.snp.makeConstraints { make in
            make.bottom.equalTo(Homepage.phoneTextField.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            Homepage.salaryTextField.font = UIFont.systemFont(ofSize: 14)
            Homepage.salaryTextField.textColor = .darkGray
            Homepage.salaryTextField.textAlignment = .center
        }
        Homepage.ibanTextField.snp.makeConstraints { make in
            make.bottom.equalTo(Homepage.salaryTextField.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            Homepage.ibanTextField.font = UIFont.systemFont(ofSize: 14)
            Homepage.ibanTextField.textColor = .darkGray
            Homepage.ibanTextField.textAlignment = .center
        }
        
    }
}
